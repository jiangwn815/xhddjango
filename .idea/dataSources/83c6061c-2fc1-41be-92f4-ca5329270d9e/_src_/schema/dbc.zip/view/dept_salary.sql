CREATE VIEW `dept_salary` AS
  SELECT
    `dbc`.`instructor`.`dept_name`   AS `dept`,
    sum(`dbc`.`instructor`.`salary`) AS `sum_salary`
  FROM `dbc`.`instructor`
  GROUP BY `dbc`.`instructor`.`dept_name`