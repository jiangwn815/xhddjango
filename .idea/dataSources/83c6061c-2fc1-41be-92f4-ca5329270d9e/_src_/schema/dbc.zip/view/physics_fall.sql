CREATE VIEW `physics_fall` AS
  SELECT
    `dbc`.`course`.`title`        AS `title`,
    `dbc`.`course`.`course_id`    AS `course_id`,
    `dbc`.`section`.`sec_id`      AS `sec_id`,
    `dbc`.`section`.`building`    AS `building`,
    `dbc`.`section`.`room_number` AS `room_number`
  FROM `dbc`.`course`
    JOIN `dbc`.`section`
  WHERE ((`dbc`.`course`.`course_id` = `dbc`.`section`.`course_id`) AND (`dbc`.`course`.`dept_name` = 'Physics') AND
         (`dbc`.`section`.`semester` = 'Fall'))