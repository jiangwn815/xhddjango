CREATE FUNCTION `d_count`(`dept_name` VARCHAR(20))
  RETURNS INT(11)
begin
declare dc integer;
select count(*) into dc
from instructor
where instructor.dept_name = dept_name;return dc;
end