CREATE PROCEDURE `in_count`(IN `dept_name` VARCHAR(20))
  begin
select count(*) from instructor where instructor.dept_name = dept_name;
end